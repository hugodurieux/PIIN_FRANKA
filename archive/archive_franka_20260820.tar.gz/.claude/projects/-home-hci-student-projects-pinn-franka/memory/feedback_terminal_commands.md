---
name: feedback-terminal-commands
description: "When giving live terminal commands during multi-terminal debugging, always label the terminal and give the full ready-to-paste command"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e92d8742-c082-4d06-9cfa-e52d59113cc4
  modified: 2026-07-21T06:45:11.621Z
---

Always specify which terminal a command goes in (e.g. "Terminal 2:"), and always give the complete, ready-to-paste command — including `source`, `cd`, and any other setup — never a bare command or a vague "run that"/"run this" referring to earlier context.

**Why:** During a long multi-terminal ROS2/MuJoCo debugging session (2026-07-21), the user explicitly asked for this after repeated back-and-forth where commands lacked terminal context or required them to mentally reassemble setup steps from earlier messages. This is now codified in this project's `CLAUDE.md` under "Giving terminal commands to the human".

**How to apply:** Any time work involves multiple concurrent terminals/shells (bringing up a simulator in one, a controller node in another, ad-hoc diagnostic commands in a third), every command block should: (1) name the terminal, (2) be fully self-contained (no relying on "already sourced" from a prior message), (3) stay on one line — no multi-line backslash-continued commands, since those have been observed to get corrupted by terminal line-wrapping and silently drop arguments. This preference likely generalizes beyond this one project to any live pair-debugging session with multiple shells.
