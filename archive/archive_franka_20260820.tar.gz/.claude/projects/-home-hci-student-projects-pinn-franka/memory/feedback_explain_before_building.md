---
name: feedback-explain-before-building
description: "State what a piece of work is for, and name the cheaper alternative, BEFORE building it"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2c7fa74d-03f3-446c-958a-b728984b5e6b
  modified: 2026-08-13T09:25:07.223Z
---

Hugo stops work to ask "à quoi ça sert ?" when I start building something whose
purpose I have not spelled out. It happened on 2026-08-13: I had written a whole
MuJoCo data collector before explaining that its point was to let the demo run
with the learned residual enabled instead of disabled.

When he got the full chain — what the demo does, what breaks, what the fix
buys, and what it costs — he chose the *cheaper* option I had not offered him
(ship with the residual off, no retraining at all).

**Why:** he optimises for the shortest path to something demonstrable, not for
the most complete solution. Building first and justifying after wastes the work
and skips the decision that was actually his to make.

**How to apply:** before writing code for anything non-trivial, give the causal
chain in a few lines — current behaviour, the specific defect, what the fix
changes — and always include the do-nothing or do-less option with its real
trade-off. Then build. Keep the honest limitation attached to the
recommendation, not buried after it.

Related: [[feedback-terminal-commands]].
