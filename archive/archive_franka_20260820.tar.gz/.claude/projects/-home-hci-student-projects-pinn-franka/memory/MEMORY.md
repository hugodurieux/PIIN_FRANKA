# Memory Index

- [Terminal command conventions](feedback_terminal_commands.md) — always label the terminal and give full ready-to-paste commands, never "run that"
- [Explain before building](feedback_explain_before_building.md) — give the causal chain and the cheaper option before writing code, not after
